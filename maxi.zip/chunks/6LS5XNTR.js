import{a as e}from"./3JX3VARJ.js";import{f as s}from"./PQ35KENF.js";var t=s(e()),n=r=>t.default.runtime.getURL(`/assets/USE_CHAT_GPT_AI${r}`);export{n as a};
