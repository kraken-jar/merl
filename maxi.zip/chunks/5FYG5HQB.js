import{a}from"./UAB7UEHC.js";import"./PQ35KENF.js";export{a as default};
