import{j as t}from"./B5YK3YMW.js";import{f}from"./PQ35KENF.js";var e=f(t()),a=e.unstable_useEnhancedEffect;export{a};
