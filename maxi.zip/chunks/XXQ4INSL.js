import{j as i}from"./B5YK3YMW.js";import{f as t}from"./PQ35KENF.js";var e=t(i()),l=e.unstable_isMuiElement;export{l as a};
