import{b as i}from"./Q6TZRKPZ.js";import{c as n}from"./PQ35KENF.js";var a=n(t=>{"use strict";var e=i();t.createRoot=e.createRoot,t.hydrateRoot=e.hydrateRoot;var s});export{a};
