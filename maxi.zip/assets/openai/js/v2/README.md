# 更新须知
## 大概率是因为ChatGPT更新了文件，只要获取官方最新的js内容替换就行，再把第三个host:n,publicKey:t的host替换成https://tcr9i.chat.openai.com就行
