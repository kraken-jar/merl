(function() {
    const importPath = /*@__PURE__*/ JSON.parse('"contentArkoseTokenIframe.js"');
    import(chrome.runtime.getURL(importPath));
})();