(function() {
    const importPath = /*@__PURE__*/ JSON.parse('"check_status.js"');
    import(chrome.runtime.getURL(importPath));
})();