import{c as w,j as d,r as E}from"./client-51d2cb66.js";import{g,l as v,P as x,S,U as C}from"./index-2c4a6595.js";import{E as q}from"./hook-702bd209.js";import{C as P}from"./index-cfdef65b.js";import{F as A}from"./index-678bca66.js";import{A as R}from"./index-c59b3a7d.js";import{T as O}from"./themeContext-5aaec797.js";import{q as j,a as W}from"./backend-fc140948.js";import{c as F}from"./index-883c478c.js";import{P as I}from"./globalFlag-58672dba.js";import"./index-6d27409c.js";import"./index-b080e7e3.js";import"./index-15f1d056.js";import"./motion-2a95696f.js";import"./IconThumbUp-d034f79b.js";import"./createReactComponent-d863982f.js";import"./index-2a566011.js";import"./analytics-1d4a96ca.js";import"./useAsyncWithPromise-477761db.js";import"./useSSE-ca2954d7.js";import"./languageLogoMap-fbade66f.js";import"./foyerLogo-9a6e287c.js";import"./index-fbb125a5.js";import"./useOnClickOutside-3645611b.js";import"./useUserSettings-142ff32e.js";import"./helper-88234660.js";import"./IconX-1f899cde.js";import"./IconCheck-14a5a2be.js";import"./v4-4a60fe23.js";import"./IconExclamationCircle-3e383487.js";import"./IconChevronRight-591d776d.js";import"./IconQuestionMark-3440143e.js";import"./IconBolt-40723880.js";import"./IconLanguage-2e75f38c.js";import"./IconAlertOctagon-b34e4dd5.js";import"./IconBulb-952e0e12.js";const M=async()=>{var a,c;const i=await g();if(i&&!i.fabStrip.twitter.visible)return;const t=(c=(a=i.fabStrip)==null?void 0:a.twitter)==null?void 0:c.containerClassname,e=await L(t);e&&!e.querySelector("merlin-component")&&T(n=>e.insertBefore(n,e.firstChild.nextSibling));const s=new MutationObserver(h((n,u)=>{try{const o=document.querySelector("[id^='typeaheadDropdownWrapped-']"),m=document.querySelector(".merlin.fabStrip");o?m&&(m.style.zIndex=0):m.style.zIndex=1e3}catch{}const l=document.querySelectorAll(t||".css-175oi2r.r-1iusvr4.r-16y2uox.r-1777fci.r-1h8ys4a.r-1bylmt5.r-13tjlyg.r-7qyjyx.r-1ftll1t");if(l.length>0)for(let o=0;o<l.length;o++)l[o].querySelector("merlin-component")||T(m=>l[o].insertBefore(m,l[o].firstChild.nextSibling))},300)),r={childList:!0,subtree:!0};s.observe(document.body,r)},L=i=>new Promise(t=>{const e=new MutationObserver(h(s=>{const r=document.querySelector(i||".css-175oi2r.r-1iusvr4.r-16y2uox.r-1777fci.r-1h8ys4a.r-1bylmt5.r-13tjlyg.r-7qyjyx.r-1ftll1t");r&&(t(r),e.disconnect())},300));e.observe(document.body,{childList:!0,subtree:!0})}),T=async i=>{var b;const t=document.createElement("merlin-component");t.id="merlin-fabStrip",t.className="merlin fabStrip";const e=t.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`${F}
    :host(.merlin.fabStrip) {
      all: initial; /* 1st rule so subsequent properties are reset. */
      position: relative;
      display: block;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      z-index: 1000;
    }
    .fabStrip {
      all: initial; /* 1st rule so subsequent properties are reset. */
      position: relative;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    .fabStrip ::-webkit-scrollbar {
      display: none;
      -ms-overflow-style: none;
      scrollbar-width: none;
    }
    `;const r=document.createElement("div");r.id="reactAppRoot",r.className="reactAppRoot fabStrip",e.appendChild(s),e.appendChild(r),i(t);const a={};let c=null,n=null,u=null,l=null,o=null,m="";try{if(n=t.closest('[data-testid="cellInnerDiv"], [aria-labelledby="modal-header"]'),n&&(o=n.querySelector("article"),o&&(c=o.querySelector('[data-testid="tweetText"]')),u=n.querySelector('[data-testid="attachments"]'),l=n.querySelector('article a div[dir="ltr"]')),c){const p=c.textContent;a.tweetText=p}l&&(m=l.textContent.trim(),a.postBy=m);try{if(u){const p=(b=u.textContent)==null?void 0:b.trim();p&&(a.quoteTweetText=p)}}catch{}}catch{}let f,y;o||u?(f=x.TWEET_REPLY,y=S.TWITTER.TWEET_REPLY):(f=x.TWEET,y=S.TWITTER.TWEET),w(r).render(d.jsx(N,{editor:t,contextData:a,promptsFor:f,mountOn:y}))};function N(i){const{contextData:t,editor:e,mountOn:s,promptsFor:r}=i,[a,c]=E.useState(""),[n=C]=q({instance:new v({area:"local"}),key:"UserSettings"});return n.merlinOnSocialMedia.visible&&n.merlinOnSocialMedia.twitter.visible?d.jsx(P,{children:d.jsx(R,{children:d.jsx(I,{client:j,persistOptions:{persister:W},children:d.jsx(O,{websiteOverride:!0,children:d.jsx(A,{editor:e,host:"twitter",contextData:t,promptsFor:r,dotMenuPosition:"top",mountOn:s,textareaValue:a,setTextareaValue:c})})})})}):null}function h(i,t){let e;return function(){const s=this,r=arguments;clearTimeout(e),e=setTimeout(()=>i.apply(s,r),t)}}M();
