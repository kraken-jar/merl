import{c as o}from"./createReactComponent-d863982f.js";var t=o("bolt","IconBolt",[["path",{d:"M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11",key:"svg-0"}]]);export{t as I};
