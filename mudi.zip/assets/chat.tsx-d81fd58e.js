import{c as a,j as t}from"./client-51d2cb66.js";import{g as n,B as c,m as d}from"./index-2c4a6595.js";import{C as l}from"./index-cfdef65b.js";import{A as h}from"./index-c59b3a7d.js";import{C as u}from"./configContext-060e848e.js";import{M as x}from"./messageContext-7b0a09a0.js";import{T as C}from"./themeContext-5aaec797.js";import{C as g,R as f,a as P}from"./index-04d35577.js";/* empty css             */import{c as j,a as y}from"./atom-one-light-7372aee1.js";import{q as v,a as E}from"./backend-fc140948.js";import{c as R}from"./index-883c478c.js";import{P as b}from"./globalFlag-58672dba.js";import"./hook-702bd209.js";import"./v4-4a60fe23.js";import"./index-6d27409c.js";import"./merlin-logo-5c2d88e0.js";import"./useMenuAnimation-ddc0dfc2.js";import"./createReactComponent-d863982f.js";import"./motion-2a95696f.js";import"./index-15f1d056.js";import"./index-e5b1d78a.js";import"./webAccessTooltip-2d2719fc.js";import"./analytics-1d4a96ca.js";import"./IconBolt-40723880.js";import"./webAccess-a10b9552.js";import"./purify.es-8e338605.js";import"./utils-f7fcf05a.js";import"./useSSE-ca2954d7.js";import"./useAsyncWithPromise-477761db.js";import"./postMessageConstants-63e2667b.js";import"./getYoutubeVideoContextData-722d9719.js";import"./IconThumbUp-d034f79b.js";import"./IconX-1f899cde.js";import"./helper-88234660.js";import"./index-cfba13e3.js";import"./IconCheck-14a5a2be.js";import"./IconCopy-9dff0a40.js";import"./IconArrowUpRight-805c79c8.js";import"./IconChevronRight-591d776d.js";import"./useOnClickOutside-3645611b.js";import"./IconChevronDown-431d82cd.js";import"./index-a57aca69.js";import"./IconBrandTwitter-58d5003f.js";import"./IconBrandMedium-8808e6d5.js";import"./languageLogoMap-fbade66f.js";import"./IconQuestionMark-3440143e.js";import"./IconLanguage-2e75f38c.js";import"./IconExclamationCircle-3e383487.js";import"./IconUser-82de231e.js";function T(){return t.jsx(l,{children:t.jsx(b,{client:v,persistOptions:{dehydrateOptions:{shouldDehydrateQuery:e=>{const{queryKey:r}=e;return!(r.includes("paginatedPublicChatbots")||r.includes("searchedChatbots"))}},persister:E},children:t.jsx(u,{children:t.jsx(h,{children:t.jsx(C,{children:t.jsx(x,{children:t.jsx(g,{children:t.jsx(f,{children:t.jsx(P,{})})})})})})})})})}const A=async()=>{if(document.getElementById("merlin-chat"))return;const e=await n();if(e&&!e.misc.chat.visible)return;const r=document.createElement("merlin-component");r.id="merlin-chat",r.className="merlin chat";const i=r.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`${R}
    :host(#merlin-chat) {
    }
    .reactAppRoot {
      all: initial; /* 1st rule so subsequent properties are reset. */
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      position: relative;
      z-index: 2147483647;
    }
    .dark {
        ${j}
    }
    ${y}
    `;const o=document.createElement("div");o.id="reactAppRoot",o.className="reactAppRoot",c.forEach(m=>{o.addEventListener(m,p=>{p.stopPropagation()})}),i.appendChild(s),i.appendChild(o),d(r),a(o).render(t.jsx(T,{}))};A();
