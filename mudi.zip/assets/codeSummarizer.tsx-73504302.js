import{c as u,j as a}from"./client-762150e3.js";import{g as l,i as b}from"./index-fa585b73.js";import{C as f}from"./index-e24a8027.js";import{u as h}from"./index-07c80c62.js";import{C as g}from"./index-95443a78.js";import{c as v}from"./index-1d123cc8.js";import"./constants-b93aee2c.js";import"./index-4f7fc425.js";import"./foyerLogo-9f3e1213.js";import"./analytics-972224a9.js";import"./index-ca2d3642.js";import"./motion-e578605b.js";import"./IconPower-b9bbd397.js";import"./createReactComponent-a79ac4d9.js";import"./hook-db053306.js";const d=o=>{let t="";const r=new MutationObserver(()=>{location.href!==t&&(t=location.href,o())}),e={childList:!0,subtree:!0};r.observe(document.body,e)};function w({code:o}){const{blackList:t,codeSummarizer:r}=h();if(r&&!t.includes(window.location.hostname))return a.jsx(g,{children:a.jsx(f,{code:o})})}const x=async()=>{const o=await l();if(o&&(!o.misc.codeSummarizer.visible||o.misc.codeSummarizer.blackListedDomains.includes(window.location.hostname)))return;const t=()=>{document.body&&new MutationObserver(b(()=>{var s,i,m,c;const e=document.querySelectorAll("code");if(e.length>0)for(let n=0;n<e.length;n++)(!((i=(s=e[n])==null?void 0:s.previousElementSibling)!=null&&i.id)||((c=(m=e[n])==null?void 0:m.previousElementSibling)==null?void 0:c.id)!=="merlin-code-summarizer")&&e[n].offsetHeight>100&&z(p=>{e[n].insertAdjacentElement("beforebegin",p)},e[n].outerText)},50)).observe(document.body,{attributes:!0,childList:!0,subtree:!0})};t(),d(()=>{t()})},z=async(o,t)=>{const r=document.createElement("merlin-component");r.id="merlin-code-summarizer",r.className="merlin-code-summarizer";const e=r.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`${v}
:host(#merlin-code-summarizer) {
    all: initial; /* 1st rule so subsequent properties are reset. */
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
.reactAppRoot{
    z-index: 1 !important;
}
`;const i=document.createElement("div");i.id="reactAppRoot",i.className="reactAppRoot",e.appendChild(s),e.appendChild(i),o(r);const m=u(i);d(()=>{m.render(a.jsx(w,{code:t}))})};x();
