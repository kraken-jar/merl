import{c as o}from"./createReactComponent-05a416dd.js";var r=o("chevron-right","IconChevronRight",[["path",{d:"M9 6l6 6l-6 6",key:"svg-0"}]]);export{r as I};
