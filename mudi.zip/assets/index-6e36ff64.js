import"./client-8f7f49dc.js";const r=({children:t})=>t;export{r as C};
