import{c as p,j as a}from"./client-51d2cb66.js";import{c as l}from"./index-883c478c.js";import{C as b}from"./index-b8b9d4d3.js";import{u as f}from"./index-4cb22604.js";import{C as h}from"./index-cfdef65b.js";import{g,i as v}from"./index-2c4a6595.js";import"./index-6d27409c.js";import"./foyerLogo-9a6e287c.js";import"./analytics-1d4a96ca.js";import"./index-15f1d056.js";import"./motion-2a95696f.js";import"./IconPower-f03880af.js";import"./createReactComponent-d863982f.js";import"./hook-702bd209.js";const d=o=>{let t="";const r=new MutationObserver(()=>{location.href!==t&&(t=location.href,o())}),e={childList:!0,subtree:!0};r.observe(document.body,e)};function w({code:o}){const{blackList:t,codeSummarizer:r}=f();if(r&&!t.includes(window.location.hostname))return a.jsx(h,{children:a.jsx(b,{code:o})})}const x=async()=>{const o=await g();if(o&&(!o.misc.codeSummarizer.visible||o.misc.codeSummarizer.blackListedDomains.includes(window.location.hostname)))return;const t=()=>{document.body&&new MutationObserver(v(()=>{var s,i,m,c;const e=document.querySelectorAll("code");if(e.length>0)for(let n=0;n<e.length;n++)(!((i=(s=e[n])==null?void 0:s.previousElementSibling)!=null&&i.id)||((c=(m=e[n])==null?void 0:m.previousElementSibling)==null?void 0:c.id)!=="merlin-code-summarizer")&&e[n].offsetHeight>100&&z(u=>{e[n].insertAdjacentElement("beforebegin",u)},e[n].outerText)},50)).observe(document.body,{attributes:!0,childList:!0,subtree:!0})};t(),d(()=>{t()})},z=async(o,t)=>{const r=document.createElement("merlin-component");r.id="merlin-code-summarizer",r.className="merlin-code-summarizer";const e=r.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=`${l}
:host(#merlin-code-summarizer) {
    all: initial; /* 1st rule so subsequent properties are reset. */
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
.reactAppRoot{
    z-index: 1 !important;
}
`;const i=document.createElement("div");i.id="reactAppRoot",i.className="reactAppRoot",e.appendChild(s),e.appendChild(i),o(r);const m=p(i);d(()=>{m.render(a.jsx(w,{code:t}))})};x();
