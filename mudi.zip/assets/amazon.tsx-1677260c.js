import{r as c,R as m,j as e,c as u}from"./client-51d2cb66.js";import{A as i,g as p,L as f}from"./index-2c4a6595.js";import{S as d}from"./merlin-logo-5c2d88e0.js";import{f as l}from"./analytics-1d4a96ca.js";import{C as b}from"./index-cfdef65b.js";import{A as x}from"./index-c59b3a7d.js";import{h,T as A}from"./themeContext-5aaec797.js";import{c as g}from"./index-883c478c.js";import"./hook-702bd209.js";function w(){const[n,t]=c.useState([]),[s,r]=c.useState(!1);return m.useEffect(()=>{s===!0&&setTimeout(()=>r(!1),3e3)},[s]),m.useEffect(()=>{(async()=>{const a=await p();a&&t(a.misc.merlinOnAmazon.questions)})()},[]),e.jsx(e.Fragment,{children:e.jsxs("div",{className:"group/amazon relative my-4 flex w-fit",children:[e.jsx("div",{className:"gradient-animated relative flex w-fit rounded-md p-[1px]",children:e.jsxs("button",{type:"button",onClick:()=>{l({eventName:"ctaOnAmazonClickedDefaultQuestion",eventType:"Button",feature:"AmazonCTA",firedFromFile:"components/ctaOnAmazon"}),window.parent.postMessage({data:{action:i.OPEN_CHAT_WEB_BLOG},type:i.OPEN_CHAT_WEB_BLOG},"*")},className:"relative flex w-fit max-w-xs flex-auto items-center justify-center gap-2 rounded-md border border-slate-400 bg-white px-3 py-2 text-slate-800",children:[e.jsx(d,{className:"h-5 w-5"}),e.jsx("span",{children:"Ask AI"})]})}),!s&&e.jsx("div",{className:"invisible absolute left-0 top-[100%] z-10 w-64 overflow-hidden bg-transparent py-2 group-hover/amazon:visible",children:e.jsxs("div",{className:"rounded-lg border border-slate-300 bg-slate-50 px-2 py-2 transition-[min-height] duration-500",children:[e.jsx("div",{className:"flex w-full flex-col gap-2",children:n.map((o,a)=>e.jsx("button",{onClick:()=>{l({eventData:o,eventName:"ctaOnAmazonClickedCustomQuestion",eventType:"Button",feature:"AmazonCTA",firedFromFile:"components/ctaOnAmazon"}),r(!0),window.parent.postMessage({data:{action:i.OPEN_CHAT_AMAZON,autoSend:!0,question:o},type:i.OPEN_CHAT_AMAZON},"*")},type:"button",className:"w-full rounded-md border border-cornblue-600 px-3 py-2 text-left text-slate-800 hover:bg-cornblue-100",children:o},a))}),e.jsxs("button",{type:"button",onClick:()=>{l({eventName:"ctaOnAmazonClickedDefaultQuestion",eventType:"Button",feature:"AmazonCTA",firedFromFile:"components/ctaOnAmazon"}),r(!0),window.parent.postMessage({data:{action:i.OPEN_CHAT_WEB_BLOG},type:i.OPEN_CHAT_WEB_BLOG},"*")},className:"mt-2 flex w-full flex-auto items-center justify-center gap-2 rounded-md border border-slate-400 bg-cornblue-600 px-3 py-2 text-white hover:bg-cornblue-500",children:[e.jsx(d,{className:"h-5 w-5"}),e.jsx("span",{children:"Ask Your Question"})]})]})})]})})}const v=async()=>{const n=await p();if(n&&(!n.misc.merlinOnAmazon||!n.misc.merlinOnAmazon.visible))return;const t=await y();t&&!t.querySelector("merlin-component")&&C(s=>t.insertBefore(s,t.lastChild.nextSibling))},y=()=>new Promise(n=>{const t=new MutationObserver(O(s=>{const r=document.querySelector("div#apex_desktop");r&&(n(r),t.disconnect())},300));t.observe(document.body,{childList:!0,subtree:!0})}),C=async n=>{const t=document.createElement("merlin-component");t.id="merlin-fabStrip",t.className="merlin fabStrip";const s=t.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=`${g}
    :host(.merlin.fabStrip) {
      all: initial; /* 1st rule so subsequent properties are reset. */
      position: relative;
      display: block;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    .fabStrip {
      all: initial; /* 1st rule so subsequent properties are reset. */
      position: relative;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    .fabStrip ::-webkit-scrollbar {
      display: none;
      -ms-overflow-style: none;
      scrollbar-width: none;
    }
    `;const o=document.createElement("div");o.id="reactAppRoot",o.className="reactAppRoot fabStrip";const a=await f.get("userThemePreference");a&&(a==="system"?h()&&(o.className+=" dark"):a==="dark"&&(o.className+=" dark")),s.appendChild(r),s.appendChild(o),n(t),u(o).render(e.jsx(N,{}))};function N(n){return e.jsx(b,{children:e.jsx(x,{children:e.jsx(A,{websiteOverride:!0,children:e.jsx(w,{})})})})}function O(n,t){let s;return function(){const r=this,o=arguments;clearTimeout(s),s=setTimeout(()=>n.apply(r,o),t)}}v();export{N as PlasmoWrappedAmazon};
