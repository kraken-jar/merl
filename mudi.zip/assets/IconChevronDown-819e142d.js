import{c as o}from"./createReactComponent-a79ac4d9.js";var e=o("chevron-down","IconChevronDown",[["path",{d:"M6 9l6 6l6 -6",key:"svg-0"}]]);export{e as I};
