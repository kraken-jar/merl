import{c as o}from"./createReactComponent-05a416dd.js";var r=o("chevron-up","IconChevronUp",[["path",{d:"M6 15l6 -6l6 6",key:"svg-0"}]]);export{r as I};
