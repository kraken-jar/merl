import{c as a}from"./createReactComponent-a79ac4d9.js";var o=a("x","IconX",[["path",{d:"M18 6l-12 12",key:"svg-0"}],["path",{d:"M6 6l12 12",key:"svg-1"}]]);export{o as I};
