import{c as e}from"./createReactComponent-d863982f.js";var a=e("power","IconPower",[["path",{d:"M7 6a7.75 7.75 0 1 0 10 0",key:"svg-0"}],["path",{d:"M12 4l0 8",key:"svg-1"}]]);export{a as I};
