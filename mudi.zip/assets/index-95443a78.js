import"./client-762150e3.js";const r=({children:t})=>t;export{r as C};
