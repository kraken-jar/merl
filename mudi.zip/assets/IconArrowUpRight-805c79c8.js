import{c as r}from"./createReactComponent-d863982f.js";var t=r("arrow-up-right","IconArrowUpRight",[["path",{d:"M17 7l-10 10",key:"svg-0"}],["path",{d:"M8 7l9 0l0 9",key:"svg-1"}]]);export{t as I};
