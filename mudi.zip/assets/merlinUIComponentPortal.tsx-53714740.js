/* empty css             */import{c as a}from"./index-01a0cd08.js";import{d as i}from"./constants-2543ad6b.js";const c=async()=>{if(document.getElementById("merlin-uicomponentportal"))return;const e=document.createElement("merlin-component");e.id="merlin-uicomponentportal",e.className="merlin merlin-uicomponentportal";const o=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=`${a}
    :host(#merlin-uicomponentportal) {
    }   
    .reactAppRoot {
      all: initial; /* 1st rule so subsequent properties are reset. */
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      position: fixed;
      top: 0;
      left: 0;
      z-index: 2147483650;
    }
    `.replaceAll(":root",":host");const t=document.createElement("div");t.id="reactAppRoot",t.className="reactAppRoot",i.forEach(r=>{t.addEventListener(r,p=>{p.stopPropagation()})}),o.appendChild(n),o.appendChild(t),document.documentElement.append(e)};c();
