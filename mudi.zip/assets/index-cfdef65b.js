import"./client-51d2cb66.js";const r=({children:t})=>t;export{r as C};
