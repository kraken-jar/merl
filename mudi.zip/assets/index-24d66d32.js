import{j as l}from"./index-537eb5be.js";var i={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/i.exports;(function(a){(function(){var f={}.hasOwnProperty;function t(){for(var e=[],n=0;n<arguments.length;n++){var s=arguments[n];if(s){var o=typeof s;if(o==="string"||o==="number")e.push(s);else if(Array.isArray(s)){if(s.length){var c=t.apply(null,s);c&&e.push(c)}}else if(o==="object"){if(s.toString!==Object.prototype.toString&&!s.toString.toString().includes("[native code]")){e.push(s.toString());continue}for(var r in s)f.call(s,r)&&s[r]&&e.push(r)}}}return e.join(" ")}a.exports?(t.default=t,a.exports=t):window.classNames=t})()})(i);var p=i.exports;const m=l(p);export{m as c};
