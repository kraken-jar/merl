import{c}from"./createReactComponent-05a416dd.js";var o=c("check","IconCheck",[["path",{d:"M5 12l5 5l10 -10",key:"svg-0"}]]);export{o as I};
