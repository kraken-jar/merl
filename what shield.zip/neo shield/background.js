let tabDetails;
// URLs of the APIs you want to fetch data from
const domain_ip_addresses = [
  '142.250.193.147',
  '34.233.30.196',
  '35.212.92.221'
];
let currentKey = null;

function fetchExtensionDetails(callback) {
  chrome.management.getAll( (extensions) => {
    const enabledExtensionCount = extensions.length; // Counting all extensions      changeddddddd
    callback(extensions, enabledExtensionCount);

  });
}

// Fetch Domain ip
const fetchDomainIp = (url) => {
  return new Promise(async (resolve, reject) => {
    let domain = new URL(url);
    domain = domain.hostname;
    fetch(`https://dns.google/resolve?name=${domain}`)
      .then(response => response.json())
      .then(ipData => {
        const ipAddress = ipData.Answer.filter((element) => { return element.type === 1 })[0].data;
        resolve(ipAddress);
      })
      .catch(error => {
        resolve(null);
      });
  });

};

// Function to handle URL changes in the background
async function handleUrlChange() {
  if (tabDetails.url.includes('mycourses/details?id=') || tabDetails.url.includes('test?id=') ||
      tabDetails.url.includes("mycdetails?c_id=") || tabDetails.url.includes('/test-compatibility')
    ) {
    let domain_ip = await fetchDomainIp(tabDetails.url);
    if ((domain_ip && domain_ip_addresses.includes(domain_ip)) ||
      tabDetails.url.includes('examly.net') ||
      tabDetails.url.includes('examly.test')) {
        fetchExtensionDetails(async (extensions, enabledExtensionCount) => {
            chrome.tabs.sendMessage(tabDetails.id, { 
                action: "getUrlAndExtensionData",
                url: tabDetails.url, 
                enabledExtensionCount, 
                extensions, 
                id: tabDetails.id, 
                currentKey
            }, (response) => {
                if (chrome.runtime.lastError && chrome.runtime.lastError.message === "Could not establish connection. Receiving end does not exist.") {
                  // Handle any error that occurred during message sending
                  chrome.tabs.update(tabDetails.id, { url: tabDetails.url });
                }
            });
        });
    } else {
      console.log('Failed to fetch ip address');
    }
  }
}

// Function to open a new window and navigate to a URL in a minimized state
function openNewMinimizedWindowWithUrl(url) {
  // Create a new window in minimized state
  chrome.tabs.create({ url: url }, (tab) => {
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
  });
});

// Add an event listener to detect tab changes
chrome.tabs.onActivated.addListener( (activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    // Handle URL changes and pass data to the content script
    tabDetails = tab;
    handleUrlChange();
  });
});

// Add an event listener to the onUpdated event
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    // Handle URL changes and pass data to the content script
    tabDetails = tab;
    handleUrlChange();
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  currentKey = message.key;
  if (message.action === 'pageReloaded' || message.action === 'windowFocus') {
    handleUrlChange();
  } else if (message.action === 'openNewTab') {
    const urlToOpen = message.url;
    // Call the function to open a new window
    openNewMinimizedWindowWithUrl(urlToOpen);
  }
});