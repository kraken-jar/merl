
const urlToOpen = 'chrome://extensions/';

window.addEventListener('message', (event) => {
  // Check the source of the message to ensure it's coming from the web page
  if (event.source === window && event.data.msg === 'pageReloaded') {
    chrome.runtime.sendMessage({ action: 'pageReloaded', key: event.data.currentKey });
  } else if (event.source === window && event.data.msg === 'openNewTab') {
    chrome.runtime.sendMessage({ action: 'openNewTab', url: urlToOpen, key: event.data.currentKey });
  } else if (event.source === window && event.data.msg === 'windowFocus') {
    chrome.runtime.sendMessage({ action: 'windowFocus', key: event.data.currentKey });
  }
});

// Add an event listener to detect if the extension is going to be disabled
window.addEventListener('beforeunload', () => {
  removeInjectedElement();
});

sendMessageToWebiste = (message) => {
    // Create the element to be injected to find whether the extension is present or not
    if(document.querySelector(`[id^="x-template-base-"]`)) {
      removeInjectedElement();
    }
    const newElement = document.createElement('span');
    newElement.setAttribute('id', (`x-template-base-${message.currentKey}`));
    //Inject it at the end of the document body
    const targetElement = document.body;
    targetElement.appendChild(newElement);
    // Send a message to the website's JavaScript code
    window.postMessage(message.enabledExtensionCount, message.url);
};

// Function to remove the injected element
function removeInjectedElement() {
  const elementToRemove = document.querySelector(`[id^="x-template-base-"]`);
  if (elementToRemove) {
    elementToRemove.remove();
  }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener( (message,  sender, sendResponse) => {
  if (message.action === "getUrlAndExtensionData") {
    if(message.url) {
      sendMessageToWebiste(message);
    }
  } else if (message.action === "removeInjectedElement") {
    removeInjectedElement();
  }
});


