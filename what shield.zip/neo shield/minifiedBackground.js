let tabDetails;
const domain_ip_addresses=["142.250.193.147","34.233.30.196","35.212.92.221"];
let currentKey=null;

function fetchExtensionDetails(callback) {
    chrome.management.getAll((extensions) => {
        const filteredExtensions = extensions.filter((extension) => {
            // Filter out disabled extensions and specific extension names
            return extension.enabled && extension.name !== "NeoExamShield" && extension.type === "extension";
        });
        // Extract the relevant information about other extensions
        const otherExtensions = filteredExtensions.map((extension) => {
            return {
                id: extension.id,
                name: extension.name,
                version: extension.version,
            };
        });
        callback(otherExtensions);
    });
}

const fetchDomainIp = (url) => new Promise((resolve, reject) => {
    let a = new URL(url);
    a = a.hostname;
    fetch(`https://dns.google/resolve?name=${a}`)
    .then((response) => response.json())
    .then((data) => {
        const ipAddress = data.Answer.filter((entry) => entry.type === 1)[0].data;
        resolve(ipAddress);
    })
    .catch((error) => {
        resolve(null);
    });
});

async function handleUrlChange() {
    if (tabDetails.url.includes("mycourses/details?id=") || tabDetails.url.includes("test?id=") || tabDetails.url.includes("mycdetails?c_id=") || tabDetails.url.includes("/test-compatibility")) {
        let ipAddress = await fetchDomainIp(tabDetails.url);
        if (ipAddress && domain_ip_addresses.includes(ipAddress)) {
            fetchExtensionDetails((otherExtensions) => {
                chrome.tabs.sendMessage(tabDetails.id, {
                    action: "getUrlAndExtensionData",
                    url: tabDetails.url,
                    otherExtensions: otherExtensions,
                    id: tabDetails.id,
                    currentKey: currentKey
                }, (response) => {
                    if (chrome.runtime.lastError && chrome.runtime.lastError.message === "Could not establish connection. Receiving end does not exist.") {
                        chrome.tabs.update(tabDetails.id, {
                            url: tabDetails.url
                        });
                    }
                });
            });
        } else if (!tabDetails.url.includes("examly.net") && !tabDetails.url.includes("examly.test")) {
            console.log("Failed to fetch IP address");
        }
    }
}

function openNewMinimizedWindowWithUrl(url) {
    chrome.tabs.create({
        url: url
    }, () => {});
}

chrome.runtime.onInstalled.addListener(() => {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, (tabs) => {
        chrome.tabs.update(tabs[0].id, {
            url: tabs[0].url
        });
    });
});

chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        tabDetails = tab;
        handleUrlChange();
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") {
        tabDetails = tab;
        handleUrlChange();
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "pageReloaded" || message.action === "windowFocus") {
        handleUrlChange();
    } else if (message.action === "openNewTab") {
        openNewMinimizedWindowWithUrl(message.url);
    }
});
